/*
    CIT 281 Project 2
    Name: Your Name
*/

// Returns a random number between min (inclusive) and max (exclusive)

const randomInt = function(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

//returns a single, random, lowercase letter

const randomLetter = function (){
    return alphabet[randomInt(1,alphabet.length-1)]; 
}

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
let result = "";

for (let i = 0; i < randomInt(5, 26); i++) {
    result += randomLetter();
}
console.log(result);



console.log(randomLetter());

//returns random length string

const randomString = function (minLength,maxLength){
    let length = randomInt(minLength,maxLength);
    let str = "";
    for(i = 1; i <= length; i++){
        str += randomLetter();
    }
    return str;
}
console.log(randomString(10,20));

//Sorts string into aplabetical order

function getSortedString(string){
    return string.split("").sort().join("");
}

console.log(getSortedString("kjasdhfkjhaskjdfhkkjasdfkjiew"));