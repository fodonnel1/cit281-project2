/*
    CIT 281 Project 2
    Name: Your Name
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
let result = "";
for (let i = 0; i < getRandomInteger(5, 26); i++) {
    result += getRandomLetter();
}
console.log(result);

//returns a single, random, lowercase letter
function getRandomLetter(){
    return alphabet[getRandomInteger(1,alphabet.length-1)]; 
}
console.log(getRandomLetter());
//returns random length string
function getRandomString(minLength,maxLength){
    let length = getRandomInteger(minLength,maxLength);
    let str = "";
    for(i = 1; i <= length; i++){
        str += getRandomLetter();
    }
    return str;
}
console.log(getRandomString(10,20));

function getSortedString(string){
    return string.split("").sort().join("");
}

console.log(getSortedString("kjasdhfkjhaskjdfhkkjasdfkjiew"));